#!/usr/bin/python

from socket import *
import time

"""
------------------------------------------------------------------------------------------------------------------
Cliente TCP que executa solicita��es em loop para evidenciar a execu��o de multiplas threads no lado do servidor.
------------------------------------------------------------------------------------------------------------------
"""

sentence = ""

# Nome ou IP utilizado para conectar ao Servidor Remoto
serverName = "localhost"

# Porta utilizada para conectar a aplicacao remota no lado Servidor
serverPort = 12000

#Executar� 5 solicita��es subsequentes
for i in range(5):
    # Cria o socket da aplicacao
    clientSocket = socket(AF_INET, SOCK_STREAM)

    # Configura o socket realizando o bind (vinculo) do endereco e da porta no socket
    clientSocket.connect((serverName, serverPort))

    # solicita o comando "/datahora"
    clientSocket.send("/datahora")

    # n�o trata o retorno, pois este script � utilizado apenas para enviar as multiplas solicita��es ao servidor.
    # o tratamento de tais solicita��es pode ser averiguada diretamente no prompt do pr�prio servidor.
