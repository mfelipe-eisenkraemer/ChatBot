# -*- coding: ISO-8859-1 -*-

import json
import urllib2
from datetime import datetime

class MensagemParser:

	mensagem = ""

	def __init__(self, mensagem):
		self.mensagem = mensagem
	
	# processa a mensagem recebida do cliente
	# retorna o processamento do comando
	def processar(self):

		# identifica a comando passado
		if self.mensagem.find('/cartola') > -1:
		
			# captura o nome do time passado junto na string de comando
			palavrasMensagem = self.mensagem.split()
			if len(palavrasMensagem) > 1:
				return self.getPontosDoTime( palavrasMensagem[1] )
			else:
				return "  --  Favor informar o nome do time conforme o exemplo: /cartola feelsgoodman"
			
		elif self.mensagem.find('/datahora') > -1:
			return self.getDataHora()
			
		elif self.mensagem.find('/donos') > -1:
			return self.getNomesDoGrupo()
			
		else:
			# se n�o foi passado um comando v�lido, retorna a mesma string, mas com todos os caracteres mai�sculos
			return self.mensagem.upper()
	
	# trata o comando </datahora>
	def getDataHora(self):
		now = datetime.now()
		return str(now.day) + "/" + str(now.month) + "/" + str(now.year) + " -- " + str(now.hour) + "h:" + str(now.minute) + "m:" + str(now.second) + "s  ::  " + str(now.microsecond) + "ms"

	# trata o comando </donos>
	def getNomesDoGrupo(self):
		return "Mateus Eisenkraemer e Roger Bianchini"
	
	# trata o comando </cartola>
	def getPontosDoTime(self, nomeDoTime):
		# busca a informa��o no site Cartola FC passando o nome do time
		timeCartola = json.load(urllib2.urlopen("https://api.cartolafc.globo.com/time/" + nomeDoTime))

		# reune os nomes obtidos em uma �nica string
		atletasDoTime = "Lista de jogadores Escalados: \n"
		for atleta in timeCartola['atletas']:
			atletasDoTime = atletasDoTime + "\n" + atleta['nome'].encode('utf-8')

		return atletasDoTime
