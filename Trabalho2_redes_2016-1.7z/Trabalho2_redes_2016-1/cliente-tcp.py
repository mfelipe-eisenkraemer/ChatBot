#!/usr/bin/python
# -*- coding: ISO-8859-1 -*-

from socket import *

"""
----------------------------------------------------------------------------------------------
Cliente TCP.
----------------------------------------------------------------------------------------------
"""

sentence = ""

# Nome ou IP utilizado para conectar ao Servidor Remoto
serverName = "localhost"

# Porta utilizada para conectar a aplicacao remota no lado Servidor
serverPort = 12000

# permanece executando o loop at� que o usu�rio digite "sair"
while sentence != "sair":
    
    # Aguarda entrada de dados pelo usu�rio no lado cliente
    sentence = raw_input("\n -- Informe uma frase ou digite sair: \n")

    if sentence != "sair":
        # Cria o socket da aplicacao
        clientSocket = socket(AF_INET, SOCK_STREAM)

        # Configura o socket realizando o bind (vinculo) do endereco e da porta no socket
        clientSocket.connect((serverName, serverPort))

        # Pega a entrada do usuario, passa para o socket e envia o dado para o Servidor remoto
        clientSocket.send(sentence)

        # Le caracteres de retorno a partir do socket e salva string recebida do Servidor
        # Note que no TCP n�o ha necessidade de associar o nome do servidor e porta pelo fato de existir a conex�o
        modifiedSentence = clientSocket.recv(1024)

        # Realiza um print da mensagem retornada pelo Servidor
        print "\n  ----  Resposta do Servidor: " , modifiedSentence + "\n"

        # Encerrando o socket logo ap�s a troca de mensagens realizada com sucesso
        clientSocket.close()

    else:
	# encerra a execu��o se digitado "sair"
        break

# fecha o prompt
exit()
