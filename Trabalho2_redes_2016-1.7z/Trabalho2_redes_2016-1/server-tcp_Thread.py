#!/usr/bin/python

"""
----------------------------------------------------------------------------------------------
Exemplo de codigo de um Servidor TCP.
----------------------------------------------------------------------------------------------
"""

from socket import *
from MensagemParser import MensagemParser
import thread
import time

nThread = 0

def conectado(connectionSocket, addr, nThreadLocal):
     
     print str(nThreadLocal) + '� Thread --- 2� EVENTO --- Criada thread para: ' + str(addr) + ' --- .\n'
     
     sentence = connectionSocket.recv(1024)

     # instancia objeto que contem a logica dos comandos implementados
     messageParser = MensagemParser(sentence)

     # delay para evidenciar o tratamento em multiplas Threads
     time.sleep(5)
     
     # processa o comando passado pelo usuario
     mensagemRetorno = messageParser.processar()
     print str(nThreadLocal) + '� Thread --- 3� EVENTO --- Processada a solicitação para: ' + str(addr) + ' = ' + mensagemRetorno + ' --- .\n'

     # envia a resposta para o cliente
     #connectionSocket.send(mensagemRetorno)
     
     # fecha o socket
     connectionSocket.close()
     print str(nThreadLocal) + '� Thread --- 4� EVENTO --- Finalizada conexao: ' + str(addr) + ' --- .\n'
     
     print str(nThreadLocal) + '� Thread --- 5� EVENTO --- Encerrada a thread para: ' + str(addr) + ' --- .\n'
     thread.exit()


# Porta que sera utilizada pelo Servidor para aguardar pedidos de conexao
serverPort = 12000

# Cria o socket da aplicacao
serverSocket = socket(AF_INET, SOCK_STREAM)

# Configura o socket realizando o bind (vinculo) da porta indicada no socket criado
serverSocket.bind(('', serverPort))

# Modifica o estado do socket para escuta de conexoes
serverSocket.listen(1)

print "O servidor esta pronto para receber!"

# Loop infinito onde fica aguardando e gerenciando os pedidos de conexao de clientes
while True:

     connectionSocket, addr = serverSocket.accept()
     nThread += 1
     print str(nThread) + '� Thread --- 1� EVENTO --- Conectado ao cliente: ' + str(addr) + ' --- .\n'
     thread.start_new_thread(conectado, tuple([connectionSocket, addr, nThread]))
